Turtle's Auto Clicker
----------------------

Turtle's Auto Clicker is a simple, lightweight auto clicker made by Turtle himself.

How to Use:
- Open the application. (Tip: You can create a desktop shortcut for quick access.)
- Adjust the CPS (clicks per second) using the slider in the app window.
- Press the 't' key on your keyboard (lower case t) to start or stop the auto clicker.

Enjoy smooth clicking power, turtle-style!
